﻿Source code of Beretta (Group 19).
Repository: https://github.com/harxhhr/beretta-cyber-insurance
Commit: 02863fb
See README.md inside the archive for how to run the system and its tests.
